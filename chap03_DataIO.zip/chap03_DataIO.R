# chap03_DataIO

########################################
##  Chapter02. 데이터의 유형과 구조 
########################################

# 1. 데이터 불러오기
## 1-1 키보드 입력
# 키보드로부터 숫자 입력하기

scan()
num <- scan()
num

#합계구하기
sum(num)

#키보드로 부터 문자 입력하기
name <- scan(what = character())
name

#편집기 이용 데이터프레임 만들기
df<-data.frame() #빈 데이터 프레임 생성
edit(df)

## 1-2 로컬 파일 가져오기
# 1) read.table() 함수 이용
#       -컬럼명이 없는 파일 불러오기
getwd()
setwd("c:/workspaces/R/data")

student <- read.table(file= "student.txt")
student

names(student) <- c('번호','이름','키','몸무게')

# - 컬럼명이 있는 파일 불러오기
student1 <- read.table(file= "student1.txt", header = T)
student1

# 탐색기를 통해서 파일 선택하기
# c:/workspaces/R/data/student1.txt 파일선택
student1 <- read.table(file.choose(), header = T)
student1

# - 구분자가 있는 경우(세미코롭, 탭)
student2 <- read.table(file= "student2.txt", sep =";", header = T)
student2
