# chap06_DataHandling

##############################
## chapter06. 데이터조작
##############################

## 1. Plyr 패키지 활용
# - 두개 이상의 데이터프레임을 대상으로 key값을 이용하여 하나의 패키지로 병합하거나, 집단변수를 기준으로 데이터프레임의 변수에 함수를 적용하여 요약집계 결과를 제공하는 패키지.

install.packages("plyr")
library(plyr)

x<- data.frame(id=c(1:5), heights=c(160,171,173,162,165))
y<- data.frame(id=c(5,4,1,3,2), weights=c(55,73,60,57,80))

z<-join(x,y,by='id')
z

x <- data.frame(id=c(1,2,3,4,6), heights=c(160,171,173,162,165))
y <- data.frame(id=c(5,4,1,3,2), weights=c(55,73,60,57,80))


left <- join(x,y,by="id")
# na 결측지
left

# 결측지가 없는것만 조인
x <- data.frame(id=c(1,2,3,4,6), heights=c(160,171,173,162,165))
y <- data.frame(id=c(5,4,1,3,2), weights=c(55,73,60,57,80))
inner <-  join(x,y,by="id",type="inner")
inner

# 결측치 포함 조인
x <- data.frame(id=c(1,2,3,4,6), heights=c(160,171,173,162,165))
y <- data.frame(id=c(5,4,1,3,2), weights=c(55,73,60,57,80))
full <-  join(x,y,by="id",type="full")
full

x = data.frame(key1 = c(1,1,2,2,3), key2 = c('a','b','c','d','e'),
               val1 = c(10,20,30,40,50))
y = data.frame(key1 = c(3,2,2,1,1), key2 = c('e','d','c','b','a'),
               val2 = c(500,400,300,200,100))
x;y
join(x,y,by=c('key1', 'key2'))

# 1.2 그룹별 기술 통계량 구하기
# (1) tapply() 함수 이용
head(iris)
names(iris)
unique(iris$Species)

tapply(iris$Sepal.Length,iris$Species,mean) 
#     setosa versicolor  virginica  평균
#     5.006      5.936      6.588 

tapply(iris$Sepal.Length,iris$Species,sd) #표준편차차 
#    setosa versicolor  virginica 
# 0.3524897  0.5161711  0.6358796

# (2) ddply() 함수이용
# 꽃의 종류별 꽃받침 길이 구하기

avg_df <- ddply(iris, .(Species),avg=mean(Sepal.Length))
avg_df
str(avg_df)

# 꽃의 종으로 여러 개의 함수 적용하기
ddply(iris,.(Species),summarise,
      avg=mean(Sepal.Length),
      std=sd(Sepal.Length), 
      max=max(Sepal.Length),
      min=min(Sepal.Length))

install.packages(c("dplyr","hflights"))

library(dplyr)
library(hflights)
str(hflights)

# 2.1 콘솔창의 크기에 맞게 데이터 추출
#     : 콜솔 창 안에서 한 눈으로 파악하기
hflights_df <- tbl_df(hflights)
hflights_df

#2.2 조건에 맞는 데이터 필터링
# hflights_df를 대상으로 1월 2일 데이터 추출하기
filter(hflights_df, Month==1 & DayofMonth==2) # OR(|)

# 2.3 커럶으로 데이터 정렬
# 년, 월, 출발시간, 도착시간 순으로 오름차순 정렬
arrange(hflights_df,Year,Month,DepTime,desc(ArrTime))

# 출발시간으로 내림차순 정렬하기
arrange(hflights_df,Year,Month,desc(DepTime),ArrTime)

# 2.4 컬럼으로 데이터 검색
#hflights_df에서 년, 월, 출발시간, 도착시간 컬럼 검색하기
select(hflights_df,Year,Month,DepTime,ArrTime)

# 컬럼의 범위 지정하기
select(hflights_df, Year:ArrTime)

# 컬럼의 범위 제외: Year부터 DayOfWeek 제외
select(hflights_df, -(Year:DayOfWeek))

# 2.5 데이터 셋에 컬럼 추가
# 출발 지연시간과 도착지연 시간과의 차이를 계산하는 컬럼 추가하기
mutate(hflights_df, gain=ArrDelay-DepDelay,
       gain_per_hour=gain/(AirTime/60))

#mutate() 함수에 의해서 추가된 컬럼보기
mutate(hflights_df, gain=ArrDelay-DepDelay,
       gain_per_hour=gain/(AirTime/60))

select(mutate(hflights_df, gain=ArrDelay-DepDelay,
       gain_per_hour=gain/(AirTime/60)), Year, Month,ArrDelay, DepDelay,gain,gain_per_hour)

# 2.6 요약 통계치 계산
# 비행시간 평균 계산하기
summarise(hflights_df, ilsu = mean(AirTime,na.rm = T))

# 데이터 셋의 관측지 길이, 출발 지연 시간 평균 구하기
summarise(hflights_df,cnt = n(), delay = mean(AirTime,na.rm = T))

#도착시간의 표준편차와 분산 계산하기
summarise(hflights_df,arrtimesd = sd(AirTime,na.rm = T), arrTimeVar= var(AirTime,na.rm = T))

#2.7 집단변수를 이용하여 그룹화하기
species <- group_by(iris,Species)
str(species)
species
# 항공기별로 그룹화
z<-group_by(hflights_df,TailNum)
str(z)

# 예시)
getwd()
setwd("C:/workspaces/R/data")

exam<- read.csv("csv_exam.csv")
exam

#filter
exam %>% filter(class==1) # %>$: 파이프연산자 (pipe 연산자)

#select()
exam %>% select(class,math,english) 

#class가 1인 행만 추출한다음 english 추출
exam %>% filter(class==1) %>% select(english)
# 기존방식
examfilter <- filter(exam,class==1)
select(examfilter,english)

#과목별 총점과 총점 기준 정렬해서 상위 6개 데이터 출력
exam %>% mutate(total=math+english+science) %>% arrange(desc(total)) %>% head(6)


## 3. reshape 패키지 활용

# 3.1 컬럼명 변경

#패키지 설치
install.packages("reshape")
library(reshape) 

# 실습 데이터 셋 가져오기
result <- read.csv("reshape.csv",header = F)
result

# 컬럼명 변경
rename(result,c(V1="total",V2="num1",V3="num2",V4="num3"))
